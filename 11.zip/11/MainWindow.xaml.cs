﻿using _11.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _11
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            var products = GetProducts();
            if (products.Count>0)
            {
                ListViewProducts.ItemsSource=products;
            }
        }
        private List<Product> GetProducts()
        {
            return new List<Product>()
            {
                new Product("RTX 3080", "85 999 P", "/Images/rtx_3080.jpg"),
                new Product("RTX 3060", "85 999 P", "/Images/rtx_3060.jpg"),
                new Product("RX 6600", "49 999 P", "/Images/rx_6600.jpg"),
                new Product("RTX 3050", "35 999 P", "/Images/rtx_3050.jpg"),
                new Product("RTX 3080 Ti", "108 999 P", "/Images/rtx_3080ti.jpg"),
                new Product("RTX 3080", "85 999 P", "/Images/rtx_3080.jpg"),
                new Product("RTX 3060", "85 999 P", "/Images/rtx_3060.jpg"),
                new Product("RX 6600", "49 999 P", "/Images/rx_6600.jpg"),
                new Product("RTX 3050", "35 999 P", "/Images/rtx_3050.jpg"),
                new Product("RTX 3080 Ti", "108 999 P", "/Images/rtx_3080ti.jpg"),
                new Product("RTX 3080", "85 999 P", "/Images/rtx_3080.jpg"),
                new Product("RTX 3060", "85 999 P", "/Images/rtx_3060.jpg"),
                new Product("RX 6600", "49 999 P", "/Images/rx_6600.jpg"),
                new Product("RTX 3050", "35 999 P", "/Images/rtx_3050.jpg"),
                new Product("RTX 3080", "85 999 P", "/Images/rtx_3080.jpg"),
                new Product("RTX 3060", "85 999 P", "/Images/rtx_3060.jpg"),
                new Product("RX 6600", "49 999 P", "/Images/rx_6600.jpg"),
                new Product("RTX 3050", "35 999 P", "/Images/rtx_3050.jpg"),
                new Product("RTX 3080 Ti", "108 999 P", "/Images/rtx_3080ti.jpg"),
                new Product("RTX 3080", "85 999 P", "/Images/rtx_3080.jpg"),
                new Product("RTX 3060", "85 999 P", "/Images/rtx_3060.jpg"),
                new Product("RX 6600", "49 999 P", "/Images/rx_6600.jpg"),
                new Product("RTX 3050", "35 999 P", "/Images/rtx_3050.jpg")
            };
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }
    }
}
